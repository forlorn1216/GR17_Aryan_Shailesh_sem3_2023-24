<div class="alert alert-<%= obj.type %> alert-dismissable center-block">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>    
    <%= obj.message %>
</div>